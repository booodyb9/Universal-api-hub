# Universal API Hub

Starter for a shared FastAPI backend. Protected endpoints require `X-API-Key` matching `HUB_API_KEY`. Do not put this key in public browser or mobile app code; use a trusted backend proxy.

## Local test (optional)
`uv sync && uv run fastapi dev main.py`

## FastAPI Cloud
Authenticate using `uv run fastapi cloud auth login --no-open --json`, then `uv run fastapi cloud deploy . --json`. Set `HUB_API_KEY` as a secret environment variable in the cloud dashboard before using protected routes.

## Current implementation
`GET /health` works; `GET /v1/projects` returns an empty placeholder; AI and webhooks deliberately return 501 until configured. Production readiness requires persistent storage, per-project authentication, rate limiting, audit logs, signature-verified webhooks, and provider adapters.
