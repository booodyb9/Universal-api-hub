import os
import secrets
from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field

app = FastAPI(title='Universal API Hub', version='0.1.0')

class Project(BaseModel):
    id: str
    name: str

class AIRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=10000)
    provider: str = 'openai'

async def authorize(x_api_key: str | None = Header(default=None)):
    configured = os.getenv('HUB_API_KEY')
    if not configured:
        raise HTTPException(status_code=503, detail='API key not configured')
    if not x_api_key or not secrets.compare_digest(x_api_key, configured):
        raise HTTPException(status_code=401, detail='Unauthorized')

@app.get('/health')
def health():
    return {'status': 'ok', 'service': 'universal-api-hub'}

@app.get('/v1/projects', dependencies=[Depends(authorize)])
def projects():
    return {'projects': [], 'note': 'Connect persistent storage to manage projects'}

@app.post('/v1/ai', dependencies=[Depends(authorize)])
def ai(req: AIRequest):
    raise HTTPException(status_code=501, detail='AI provider adapter not configured')

@app.post('/v1/webhooks/{source}', dependencies=[Depends(authorize)])
def webhook(source: str):
    raise HTTPException(status_code=501, detail='Configure provider-specific signature verification before enabling webhooks')
